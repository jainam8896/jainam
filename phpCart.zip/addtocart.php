<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add to Cart</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <script src="./js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="./style.css">
</head>

<body>
    <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-info">
            <div class="container-fluid">
                <img src="./img/gaming1.jpeg" alt="" class="logo">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index1.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="display_all.php">Product</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./user_area/user_registration.php">Register</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./addtocart.php"><i class="fa-solid fa-cart-shopping"></i><sup>1</sup></a>
                        </li>
                    </ul>
                    <form class="d-flex" action="search_product.php" method="get">
                        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" name="search_data">
                        <input type="submit" value="Search" class="btn btn-outline-light" name="search_data_product">
                    </form>
                </div>
            </div>
        </nav>

        <div class="bg-light">
            <h3 class="text-center">Gaming Store</h3>
            <p class="text-center">Welcome To Gaming World</p>
        </div>

        <h3 class="text-center">Add To Cart</h3>
        <table class="table table-bordered mt-5">
            <thead>
                <tr class="text-center">
                    <th >Product ID</th>
                    <th >Product Image</th>
                    <th >Product Name</th>
                    <th >Qty</th>
                    <th >Product Price</th>
                    <th >Total</th>
                    <th >delete</th>

                </tr>
            </thead>
            <tbody>
                
                <?php
                $i=0;
                 foreach($_SESSION['cart'] as $k=>$v){
                    $i++;
                    echo'
                    <tr class="text-center">
                    <td>'.$i.'</td>
                    <td><img src="./admin_area/product_images/'.$v['img'].'" width="50px" height="50px" alt=""></td>
                    <td>'.$v['title'].'</td>
                    
                    <form action="./funcation/managecart.php" method="post">
                        <input type="hidden" name="hidid" value="'.$v['id'].'">
                    <td><button type="submit" class="btn btn-outline-danger" name="sub">-</button>
                    '.$v['qty'].'
                    <button type="submit" class="btn btn-outline-success" name="add">+</button>
                    </td>


                    <td>'.$v['price'].'</td>
                    <td>'.$v['price']*$v['qty'].'</td>
                    <td><button type="submit" class="btn btn-outline-danger" name="del">Delete</button></form></td>
                </tr>   
                    ';
                 }
                ?>
                
            
            </tbody>
        </table>
        
    </div>
</body>


</html>