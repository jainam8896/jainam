<?php
session_start();
// print_r($_SESSION);
if(isset($_POST['addtocart']))
{
    if(isset($_SESSION['cart'])){
    $c=count($_SESSION['cart']);
    $idds=array_column($_SESSION['cart'],"id");
    if(in_array($_POST['hidid'],$idds)){
        echo "<script>alert('item already added');window.location.href='../addtocart.php';</script>";
    }
    else{
    $_SESSION['cart'][$c]=array(
        'id'=>$_POST['hidid'],
        'price'=>$_POST['hidprice'],
        'title'=>$_POST['hidtitle'],
        'img'=>$_POST['hidimg'],
        'qty'=>$_POST['hidqty'],
        
    );
    echo "<script>alert('item added');window.location.href='../addtocart.php';</script>";
    }}
    else{
        $_SESSION['cart'][0]=array(
            'id'=>$_POST['hidid'],
            'price'=>$_POST['hidprice'],
            'title'=>$_POST['hidtitle'],
            'img'=>$_POST['hidimg'],
            'qty'=>$_POST['hidqty'],
            
        );
        echo "<script>alert('item added');window.location.href='../addtocart.php';</script>";
    }
}
if (isset($_POST['del'])){
    foreach($_SESSION['cart'] as $k => $v){
        if($v['id']==$_POST['hidid']){
            unset($_SESSION['cart'][$k]);
            $_SESSION['cart']=array_values($_SESSION['cart']);
            echo "<script>alert('Item Removed');window.location.href='../addtocart.php';</script>";    
        }
    }
}
if (isset($_POST['add'])){

    foreach($_SESSION['cart'] as $k => $v){
        if($v['id']==$_POST['hidid']){
            if($_SESSION['cart'][$k]['qty']<3){
            $_SESSION['cart'][$k]['qty']+=1;
            echo "<script>window.location.href='../addtocart.php';</script>";
        }
        else{
            echo "<script>alert('you have selected maximum quantity');window.location.href='../addtocart.php';</script>";
        }
                
        }
    }
}
if (isset($_POST['sub'])){

    foreach($_SESSION['cart'] as $k => $v){
        if($v['id']==$_POST['hidid']){
            if($_SESSION['cart'][$k]['qty']>1){
            $_SESSION['cart'][$k]['qty']-=1; 
            echo "<script>window.location.href='../addtocart.php';</script>";
            }
            else{
                echo "<script>alert('Minimum quantity is 1');window.location.href='../addtocart.php';</script>"; 
            }
        }
    }
} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<img src="" alt="">
<body>
    
</body>
</html>